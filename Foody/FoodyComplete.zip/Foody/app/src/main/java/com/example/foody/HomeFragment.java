package com.example.foody;

import android.app.AlertDialog;
import android.content.Context;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.os.Bundle;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.foody.R;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Iterator;

public class HomeFragment extends Fragment {

    private static ArrayList<String> purchasedItems = new ArrayList<>();
    private JSONObject foodData;

    // Public static method to access purchased items
    public static ArrayList<String> getPurchasedItems() {
        return purchasedItems;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_home, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        EditText foodNameEditText = view.findViewById(R.id.foodNameEditText);
        Button searchButton = view.findViewById(R.id.searchButton);

        // Search button logic
        searchButton.setOnClickListener(v -> {
            String foodName = foodNameEditText.getText().toString().trim();
            if (!foodName.isEmpty()) {
                searchFood(foodName); // Search for the food item
                foodNameEditText.setText(""); // Reset the EditText after searching
                foodNameEditText.setHint("Enter food name"); // Reset the hint explicitly
            } else {
                Toast.makeText(getContext(), "Please enter a valid food name", Toast.LENGTH_SHORT).show();
            }
        });
    }

    // Search for a food item (simulated search function)
    private void searchFood(String foodName) {
        // Simulated logic: Show the details for any search input
        showFoodDetailsDialog(foodName);

        // Trigger vibration after a successful search
        vibrate();
    }

    // Display food details in a dialog with "Add to Cart" and "Go Back" buttons
    private void showFoodDetailsDialog(String foodName) {
        // Simulated food data (this can be replaced with actual data)
        String foodInfo = "{\"calories\": 150, \"origin\": \"USA\", \"category\": \"Fruit\", \"Vitamins\": [\"Vitamin C\", \"Vitamin A\"]}";

        AlertDialog.Builder builder = new AlertDialog.Builder(requireContext());
        builder.setTitle("Food Details: " + foodName);

        try {
            JSONObject json = new JSONObject(foodInfo);

            // Display food details dynamically
            StringBuilder details = new StringBuilder();
            Iterator<String> keys = json.keys();
            while (keys.hasNext()) {
                String key = keys.next();
                String label = key.replace("_", " "); // Replace underscores with spaces
                Object value = json.get(key);

                if (value instanceof String || value instanceof Number) {
                    details.append("<b>").append(label).append(":</b> ").append(value).append("<br>");
                } else if (value instanceof org.json.JSONArray) {
                    details.append("<b>").append(label).append(":</b> ");
                    org.json.JSONArray array = (org.json.JSONArray) value;
                    for (int i = 0; i < array.length(); i++) {
                        details.append(array.getString(i));
                        if (i != array.length() - 1) {
                            details.append(", ");
                        }
                    }
                    details.append("<br>");
                }
            }

            builder.setMessage(Html.fromHtml(details.toString(), Html.FROM_HTML_MODE_LEGACY));
        } catch (Exception e) {
            builder.setMessage("Error displaying food details.");
        }

        // "Add to Cart" button
        builder.setPositiveButton("Add to Cart", (dialog, which) -> {
            purchasedItems.add(foodName);
            Toast.makeText(getContext(), foodName + " added to cart.", Toast.LENGTH_SHORT).show();
        });

        // "Go Back" button
        builder.setNegativeButton("Go Back", (dialog, which) -> dialog.dismiss());

        builder.create().show();
    }

    // Trigger device vibration
    private void vibrate() {
        Vibrator vibrator = (Vibrator) requireContext().getSystemService(Context.VIBRATOR_SERVICE);
        if (vibrator != null && vibrator.hasVibrator()) {
            vibrator.vibrate(VibrationEffect.createOneShot(200, VibrationEffect.DEFAULT_AMPLITUDE));
        }
    }
}
