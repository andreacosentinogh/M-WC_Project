package com.example.foody.ui;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.foody.CustomValueFormatter;
import com.example.foody.R;
import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.formatter.IndexAxisValueFormatter;
import com.github.mikephil.charting.formatter.ValueFormatter;

import java.util.ArrayList;
import java.util.HashMap;

public class UserDataFragment extends Fragment {

    // List to store user purchase data
    private static ArrayList<HashMap<String, Object>> userPurchases = new ArrayList<>();

    // Static method to add purchase data
    public static void addUserData(HashMap<String, Object> purchaseData) {
        userPurchases.add(purchaseData);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_user_data, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        // Initialize the bar chart
        BarChart barChart = view.findViewById(R.id.barChart);
        setupBarChart(barChart);

        // Calculate and display totals
        calculateAndDisplayTotals(view);
    }

    // Method to set up the bar chart
    private void setupBarChart(BarChart barChart) {
        ArrayList<BarEntry> entries = new ArrayList<>();
        ArrayList<String> labels = new ArrayList<>();

        int index = 0;
        for (HashMap<String, Object> purchase : userPurchases) {
            float quantity = ((Number) purchase.get("quantity")).floatValue();
            entries.add(new BarEntry(index, quantity));
            labels.add((String) purchase.get("item")); // Product names as labels
            index++;
        }

        // Create dataset and configure the chart
        BarDataSet dataSet = new BarDataSet(entries, "Products Bought");
        BarData data = new BarData(dataSet);
        data.setValueTextSize(12f);
        data.setDrawValues(true);
        data.setValueFormatter(new CustomValueFormatter());

        XAxis xAxis = barChart.getXAxis();
        xAxis.setValueFormatter(new IndexAxisValueFormatter(labels));
        xAxis.setPosition(XAxis.XAxisPosition.BOTTOM);
        xAxis.setGranularity(1f);
        xAxis.setGranularityEnabled(true);
        xAxis.setLabelCount(labels.size());
        xAxis.setTextSize(12f);

        barChart.getAxisLeft().setGranularity(1f);
        barChart.getAxisLeft().setValueFormatter(new CustomValueFormatter());
        barChart.getAxisRight().setEnabled(false);
        barChart.setData(data);
        barChart.setFitBars(true);
        barChart.getDescription().setEnabled(false);
        barChart.invalidate();
    }

    // Method to calculate and display totals
    private void calculateAndDisplayTotals(View view) {
        int totalProducts = 0;
        float totalCalories = 0;
        float totalCO2 = 0;

        // Iterate through user purchases and sum up values
        for (HashMap<String, Object> purchase : userPurchases) {
            totalProducts += (int) purchase.get("quantity");
            totalCalories += ((Number) purchase.get("calories")).floatValue();
            totalCO2 += ((Number) purchase.get("co2")).floatValue();
        }

        // Display the totals in TextViews
        TextView totalProductsTextView = view.findViewById(R.id.totalProducts);
        TextView totalCaloriesTextView = view.findViewById(R.id.totalCalories);
        TextView totalCO2TextView = view.findViewById(R.id.totalCO2);

        totalProductsTextView.setText("Total Products: " + totalProducts);
        totalCaloriesTextView.setText("Total Calories: " + totalCalories);
        totalCO2TextView.setText("Total CO2: " + totalCO2 + " kg");
    }
}



