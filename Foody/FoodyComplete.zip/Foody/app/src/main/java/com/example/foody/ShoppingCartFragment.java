package com.example.foody;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.foody.R;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;

public class ShoppingCartFragment extends Fragment {

    private ArrayList<String> purchasedItems;
    private TextView cartItemsTextView;
    private Button confirmButton;

    public ShoppingCartFragment(ArrayList<String> purchasedItems) {
        this.purchasedItems = purchasedItems;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_shopping_cart, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        cartItemsTextView = view.findViewById(R.id.cartItemsTextView);
        confirmButton = view.findViewById(R.id.confirmButton);

        displayPurchasedItems();

        confirmButton.setOnClickListener(v -> {
            // Save each item in the user data
            for (String item : purchasedItems) {
                HashMap<String, Object> purchaseData = new HashMap<>();
                String currentDate = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());

                purchaseData.put("date", currentDate);
                purchaseData.put("item", item);
                purchaseData.put("quantity", 1); // Example quantity, replace with dynamic data
                purchaseData.put("calories", 150.0f); // Example calories
                purchaseData.put("co2", 0.5f); // Example CO2 emissions in kg
                com.example.foody.ui.UserDataFragment.addUserData(purchaseData);
            }

            // Clear the cart
            purchasedItems.clear();
            displayPurchasedItems();
        });
    }

    private void displayPurchasedItems() {
        if (purchasedItems.isEmpty()) {
            cartItemsTextView.setText("Your cart is empty.");
        } else {
            StringBuilder items = new StringBuilder();
            for (String item : purchasedItems) {
                items.append("• ").append(item).append("\n");
            }
            cartItemsTextView.setText(items.toString());
        }
    }
}
