package com.example.foody;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.text.format.DateFormat;
import android.util.Log;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.Iterator;

public class DBHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "scan_data.db";
    private static final int DATABASE_VERSION = 4;  // Keep track of schema versions

    private Context context;

    private static final String CREATE_TABLE_SCAN_DATA =
            "CREATE TABLE IF NOT EXISTS scan_data (" +
                    "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    "food_name TEXT, " +
                    "calories REAL, " +
                    "origin TEXT, " +
                    "carbon_footprint REAL, " +
                    "category TEXT, " +
                    "scan_date TEXT" +
                    ");";

    public DBHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
        this.context = context;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_TABLE_SCAN_DATA);
        // After creating the table, populate it from the raw JSON file
        loadInitialDataFromJSON(db);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Add scan_date column if it doesn't exist
        try {
            db.execSQL("ALTER TABLE scan_data ADD COLUMN scan_date TEXT;");
        } catch (Exception e) {
            // Column might already exist, or first creation
        }
    }

    public boolean insertData(String foodName, double calories, String origin, double carbonFootprint, String category) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("food_name", foodName.toLowerCase());
        contentValues.put("calories", calories);
        contentValues.put("origin", origin);
        contentValues.put("carbon_footprint", carbonFootprint);
        contentValues.put("category", category);

        // Add current date to scan_date column
        String currentDate = DateFormat.format("yyyy-MM-dd", new java.util.Date()).toString();
        contentValues.put("scan_date", currentDate);

        long result = db.insert("scan_data", null, contentValues);
        return result != -1;
    }

    private void loadInitialDataFromJSON(SQLiteDatabase db) {
        try {
            // Load the JSON from raw resources
            InputStream is = context.getResources().openRawResource(R.raw.food_info);
            int size = is.available();
            byte[] buffer = new byte[size];
            is.read(buffer);
            is.close();

            String json = new String(buffer, StandardCharsets.UTF_8);
            JSONObject jsonObject = new JSONObject(json);

            // Iterate through the keys (food names)
            Iterator<String> keys = jsonObject.keys();
            while (keys.hasNext()) {
                String foodName = keys.next();
                JSONObject foodDetails = jsonObject.getJSONObject(foodName);

                double calories = foodDetails.optDouble("calories", 0.0);
                String origin = foodDetails.optString("origin", "Unknown");
                double carbonFootprint = foodDetails.optDouble("carbon_footprint", 0.0);
                String category = foodDetails.optString("category", "Unknown");

                // Insert into database
                ContentValues contentValues = new ContentValues();
                contentValues.put("food_name", foodName.toLowerCase());
                contentValues.put("calories", calories);
                contentValues.put("origin", origin);
                contentValues.put("carbon_footprint", carbonFootprint);
                contentValues.put("category", category);

                // Initially, we can set scan_date to null or just current date if desired
                String currentDate = DateFormat.format("yyyy-MM-dd", new java.util.Date()).toString();
                contentValues.put("scan_date", currentDate);

                db.insert("scan_data", null, contentValues);
            }

        } catch (Exception e) {
            Log.e("DBHelper", "Error loading initial data", e);
            Toast.makeText(context, "Error loading initial food data", Toast.LENGTH_SHORT).show();
        }
    }
}
